<h1 align="center">UI template using HTML, CSS and Javascript :fire:</h1>

<h3>:one: Login screen: :arrow_down:</h3>
<p align="center">
  <img src="img/screenshots/login.png">
</p>

<h3>:two: Register screen: :arrow_down:</h3>
<p align="center">
  <img src="img/screenshots/register.png">
</p>

<h3>:three: Recover password screen: :arrow_down:</h3>
<p align="center">
  <img src="img/screenshots/recover.png">
</p>

<h3>:four: Register confirmation screen: :arrow_down:</h3>
<p align="center">
  <img src="img/screenshots/confirm.png">
</p>

<h3>:five: Register Error screen: :arrow_down:</h3>
<p align="center">
  <img src="img/screenshots/error.png">
</p>
